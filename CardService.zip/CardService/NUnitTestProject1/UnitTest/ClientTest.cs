using ClientLibrary.Clients;
using ClientLibrary.Model;
using NUnit.Framework;

namespace Tests
{
    [TestFixture]
    public class ClientTest
    {
        [Test]
        public void GetCardTest()
        {
            Hdfc oHdfc = new Hdfc();
            var result = oHdfc.GetCard("EX12345678");
            Assert.AreEqual(new CardInformation().GetType(), result.GetType());
        }
    }
}