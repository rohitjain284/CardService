﻿using CardService;
using CardService.Contract;
using NUnit.Framework;

namespace Test.UnitTest
{
    public class CardDetailsTest
    {
        [Test]
        public void GetCardTest()
        {
            string institutionid = "9163";
            string cardIdentifier = "EX12345678";
            ICardDetails cardDetails = new CardDetails();
            var result = cardDetails.GetCard(institutionid, cardIdentifier);
            Assert.AreEqual(cardIdentifier, result.CardIdentifier);
        }
    }
}
